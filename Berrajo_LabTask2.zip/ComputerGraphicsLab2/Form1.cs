﻿using ComputerGraphicsLab2.Dithering;
using ComputerGraphicsLab2.ImageParameters;
using ComputerGraphicsLab2.ImageUtilities;
using ComputerGraphicsLab2.Quantization;
using ComputerGraphicsLab2.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComputerGraphicsLab2
{
    public partial class Form1 : Form
    {
        private Form1 form1;
        private ErrorDiffusion errorDiffusion;

        private OctreeQuantizer parent = new OctreeQuantizer();
        private List<Color> limitedPalette = new List<Color>();
        private List<Color> originalPalette = new List<Color>();

        private Bitmap _image;
        private Bitmap _transformed;

        public Form1()
        {
            InitializeComponent();
            form1 = this;
            errorDiffusion = new ErrorDiffusion(form1);
        }

        #region Open and Load

        private void OpenPicture_Click(object sender, EventArgs e)
        {
            using(FileDialog dialog = new OpenFileDialog
            {
                Title = "Open Image",
                DefaultExt = "png",
                Filter = "All Pictures (*.emf;*.wmf;*.jpg;*.jpeg;*.jfif;*.jpe;*.png;*.bmp;*.dib;*.rle;*.gif;*.tif;*.tiff)|*.emf;*.wmf;*.jpg;*.jpeg;*.jfif;*.jpe;*.png;*.bmp;*.dib;*.rle;*.gif;*.tif;*.tiff|Windows Enhanced Metafile (*.emf)|*.emf|Windows Metafile (*.wmf)|*.wmf|JPEG File Interchange Format (*.jpg;*.jpeg;*.jfif;*.jpe)|*.jpg;*.jpeg;*.jfif;*.jpe|Portable Networks Graphic (*.png)|*.png|Windows Bitmap (*.bmp;*.dib;*.rle)|*.bmp;*.dib;*.rle|Graphics Interchange Format (*.gif)|*.gif|Tagged Image File Format (*.tif;*.tiff)|*.tif;*.tiff|All files (*.*)|*.*"
            })
            {
                if(dialog.ShowDialog(this) == DialogResult.OK)
                {
                    this.OpenImage(dialog.FileName);
                }
            }
        }

        private void OpenImage(string fileName)
        {
            try
            {
                using(Bitmap image = (Bitmap)Image.FromFile(fileName))
                {
                    this.OpenImage(image);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void OpenImage(Bitmap bitmap)
        {
            this.CleanUpOriginal();

            _image = bitmap.Copy();

            OriginalPicture.Image = _image;

            // Filling the octree initially
            for(int y = 0; y < _image.Height; y++)
            {
                for(int x = 0; x < _image.Width; x++)
                {
                    Color c = _image.GetPixel(x, y);
                    parent.AddColor(c);
                }
            }

            this.CreateTransformedImage();
        }

        private void CleanUpOriginal()
        {
            OriginalPicture.Image = null;

            if(_image != null)
            {
                _image.Dispose();
                _image = null;
            }
        }

        private void CleanUpTransformed()
        {
            WorkedPicture.Image = null;

            if(_transformed != null)
            {
                _transformed.Dispose();
                _transformed = null;
            }
        }

        #endregion

        #region Dithering and Grayscale

        private void CreateTransformedImage()
        {
            Bitmap bitmap;
            ArgbColor[] originalData;
            Size size;
            IErrorDiffusion dither;

            this.CleanUpTransformed();

            bitmap = _image;
            size = bitmap.Size;

            int levels = (int)GrayscaleLevel.Value;
            int matrix = (int)ditherMatrix.Value;
            originalData = bitmap.GetPixelsFrom32BitArgbImage();

            dither = errorDiffusion.GetDitheringInstance();

            for (int row = 0; row < size.Height; row++)
            {
                for (int col = 0; col < size.Width; col++)
                {
                    int index;
                    ArgbColor current;
                    ArgbColor transformed;

                    index = row * size.Width + col;

                    current = originalData[index];

                    // transform the pixel - normally this would be some form of color
                    // reduction. For this sample it's simple threshold based
                    // monochrome conversion
                    transformed = PixelUtilities.TransformPixel(current, form1);
                    originalData[index] = transformed;

                    // apply a dither algorithm to this pixel
                    if (dither != null)
                    {
                        dither.Diffuse(originalData, current, transformed, col, row, size.Width, size.Height, levels, matrix);
                    }
                }
            }

            _transformed = originalData.ToBitmap(size);
            WorkedPicture.Image = _transformed;
        }

        private void DitherCheckBoxCheckedHandler(object sender, EventArgs e)
        {
            this.CreateTransformedImage();
        }

        #endregion

        #region Uniform quantization

        private void uniform_CheckedChanged(object sender, EventArgs e)
        {
            WorkedPicture.Image = _image;
            Bitmap bitmap = _image;

            // Creates intervals with subdivision values
            List<int> listOfRIntervals = CreateInervals(Int32.Parse(subdivision_kr.Text));
            List<int> listOfGIntervals = CreateInervals(Int32.Parse(subdivision_kg.Text));
            List<int> listOfBIntervals = CreateInervals(Int32.Parse(subdivision_kb.Text));

            for (int y = 0; y < bitmap.Height; y++)
            {
                for (int x = 0; x < bitmap.Width; x++)
                {
                    Color pixel = bitmap.GetPixel(x, y);
                    int[] rgb = new int[3];

                    // Gets the channel value for each ARGB color
                    rgb[0] = GetChannelValue(listOfRIntervals, pixel.R);
                    rgb[1] = GetChannelValue(listOfGIntervals, pixel.G);
                    rgb[2] = GetChannelValue(listOfBIntervals, pixel.B);

                    bitmap.SetPixel(x, y, Color.FromArgb(pixel.A, rgb[0], rgb[1], rgb[2]));
                }
            }

            WorkedPicture.Image = bitmap;
        }

        private int GetChannelValue(List<int> listIntervals, int pixelRGBValue)
        {
            int r = 0;

            foreach (var interval in listIntervals)
            {
                if (pixelRGBValue > listIntervals.ElementAt(listIntervals.Count - 1))
                {
                    r = (listIntervals.ElementAt(listIntervals.Count - 1) + listIntervals.ElementAt(listIntervals.Count - 2)) / 2;
                    break;
                }
                else if (pixelRGBValue < interval)
                {
                    var it = listIntervals.IndexOf(interval);
                    r = (listIntervals[it] + listIntervals[it - 1]) / 2;
                    break;
                }
            }

            return r;
        }

        private List<int> CreateInervals(int v)
        {
            List<int> list = new List<int>();

            for (int i = 0; i <= v; i++)
            {
                list.Add(((255 * i) / v));
            }

            return list;
        }

        #endregion

        #region Octree Quantization

        private void octree_CheckedChanged(object sender, EventArgs e)
        {
            WorkedPicture.Image = _image;
            Bitmap bitmap = _image;
            Color color;

            for (int y = 0; y < bitmap.Height; y++)
            {
                for (int x = 0; x < bitmap.Width; x++)
                {
                    color = bitmap.GetPixel(x, y);
                    parent.AddColor(color);
                }
            }

            int limit = Int32.Parse(kmax.Text);
            
            limitedPalette = parent.GetPalette(limit);

            Bitmap quantizedImage = new Bitmap(bitmap.Width, bitmap.Height);

            for (int y = 0; y < bitmap.Height; y++)
            {
                for (int x = 0; x < bitmap.Width; x++)
                {
                    quantizedImage.SetPixel(x, y, limitedPalette[parent.GetPaletteIndex(_image.GetPixel(x, y))]);
                }
            }

            WorkedPicture.Image = quantizedImage;
        }

        #endregion

        private void Reset_Click(object sender, EventArgs e)
        {
            //this.OpenImage(_image);
        }

        private void Apply_Click(object sender, EventArgs e)
        {

        }

        private void OrderedDitheringRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.CreateTransformedImage();
        }
    }
}
